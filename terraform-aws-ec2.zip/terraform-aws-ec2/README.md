# Simple Terraform AWS EC2 Example

This project creates an AWS EC2 instance using Terraform.

## Usage

1. Configure your AWS CLI (`aws configure`)
2. Initialize Terraform

   ```
   terraform init
   ```

3. Preview changes

   ```
   terraform plan
   ```

4. Apply changes

   ```
   terraform apply
   ```

5. Destroy resources (when done)

   ```
   terraform destroy
   ```